# Stage 2 parser fix

Точечный patch только для `IminfinPageSessionParser`.

Что меняется:
- больше не ищем только `reportId=...`
- поддерживаем современные маркеры iMinfin из HTML/JS страницы:
  - `UUID: "..." найден в списке рубрикатора`
  - `использую версию отчета из рубрикатора: 015 (27.05.2025 15.32.03.296)`
- сохраняем прежние fallback-пути через `reportId=...`, `dataVersion=...`, `version=...`
- `uuid=...` из resource-url используем только как последний фоллбек, потому что на страницах встречаются старые служебные uuid для `customResources`

Как применять:
1. Заменить файл:
   `infrastructure-collector-iminfin/src/main/java/Ogni/ODAS/iminfin/session/parser/IminfinPageSessionParser.java`
2. Пересобрать модуль и запустить приложение.

Что этот patch не делает:
- не меняет HTTP client
- не меняет orchestrator discovery
- не меняет persistence/model/DB

Ожидаемый эффект:
- профили `EXPENSES_COMPARE`, `EXPENSES_DETAIL`, `CREDITS_COMPARE`, `FIN_SOURCES_DETAIL`
  перестанут падать на `Failed to extract iMinfin reportId from page`
- если останутся ошибки по `INCOMES_*`, это уже отдельная транспортная проблема HTTP timeout
